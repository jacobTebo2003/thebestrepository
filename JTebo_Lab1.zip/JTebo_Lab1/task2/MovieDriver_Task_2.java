import java.util.Scanner; 
public class MovieDriver {

	public static void main(String[] args) {
		
		movieLooper();
		

	}
	
	public static void movieLooper()
	
	{
		Scanner keyboard = new Scanner (System.in);
		String validate;
		char repeat;
		Movie movie = new Movie();
		
		
		do
		{
			
			String movieName, movieRating;
			int movieTickets;
			
			System.out.println("Enter the name of a movie: ");
			movieName = keyboard.nextLine();
			movie.setTitle(movieName);

			
			System.out.println("Enter the rating of the movie: ");
			movieRating = keyboard.nextLine();
			movie.setRating(movieRating);
			

			
			System.out.println("Enter the tickets sold for this movie: ");
			movieTickets = keyboard.nextInt();
			movie.setSoldTickets(movieTickets);
			
			keyboard.nextLine();
			
			System.out.println(movie.toString());
			
			System.out.println("Would you like to enter another? Y or N");
			validate = keyboard.nextLine();
			repeat = validate.charAt(0);
			
		
			
		} while (repeat == 'y'|| repeat == 'Y');
		
		keyboard.nextLine();
		
		System.out.println("goodbye");
		
	}

}
